# mednet

To start the app run:

```
export FLASK_APP=server.py
set FLASK_APP=server.py
flask run
```

I also had to disable the cache in my chrome browser to work on styling.
